# Malla Interactiva de Derecho

Este proyecto contiene una malla curricular interactiva de la carrera de Derecho, diseñada para ser utilizada en navegadores web.

## Características

- Visualización por semestres (1 al 10)
- Cursos desbloqueables según sus prerrequisitos
- Interfaz en color lila
- Posibilidad de marcar los cursos como completados

## Cómo usar

1. Descarga o clona este repositorio.
2. Abre el archivo `malla_derecho_interactiva.html` en cualquier navegador web moderno.
3. Haz clic sobre los cursos para marcarlos como completados y desbloquear los siguientes.

## Créditos

Desarrollado con ❤️ para apoyar la organización académica de estudiantes de Derecho.
